Announcer Script Forked By !Nates#0002

For Support Join https://discord.gg/jcJsZUUYuH


-This Is A Simple Auto Announcement Script
-Standalone Script
-Runs At A 0.00 Resmon (Optimized)
-Server Sided Script
-Editable Announcement Messages, (Edit In Config.lua)
-Changeable Text And Text Box Colors
-Free Source Code Script
