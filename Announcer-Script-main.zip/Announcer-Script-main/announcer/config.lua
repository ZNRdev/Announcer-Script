Basic = {
    AnnouncerDelay = 10, -- in seconds must be integer
    Msgs = { -- You can add unlimited messages
        [1] = {text = "Message 1 Here"},
        [2] = {text = "Message 2 Here"},
        [3] = {text = "Message 3 Here"},
        [4] = {text = "Message 4 Here"},
    }
}

