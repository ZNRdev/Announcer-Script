fx_version 'cerulean'
games { 'gta5' }

Author 'Nates' -- https://discord.gg/jcJsZUUYuH
description 'Simple Announcer Script'
version '1.1.0'

server_scripts {
   'config.lua',
   'server/*',
}


